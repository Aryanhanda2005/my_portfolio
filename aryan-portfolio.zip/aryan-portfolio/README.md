# Aryan Handa — Portfolio

## Deploy in 60 seconds (Netlify — free)

1. Go to https://app.netlify.com/drop
2. Drag and drop this entire folder onto the page
3. Your site is live instantly ✅

## Deploy via GitHub Pages (free)

1. Create a new GitHub repo (e.g. `aryan-portfolio`)
2. Upload `index.html` to the repo
3. Go to Settings → Pages → Source → main branch → / (root)
4. Your site will be live at `https://yourusername.github.io/aryan-portfolio`

## Edit the portfolio

Open `index.html` in any text editor and search for:

| What to change          | Search for                     |
|-------------------------|-------------------------------|
| Your email              | `you@example.com`             |
| GitHub link             | `href="https://github.com/"`  |
| LinkedIn link           | `href="https://linkedin.com/"`|
| Twitter link            | `href="https://twitter.com/"` |
| 2025 timeline entry     | `// edit this entry...` (2025)|
| 2026 timeline entry     | `// edit this entry...` (2026)|
| Project live link       | `[ ENTER DUNGEON ]` href="#"  |
| Project source link     | `[ SOURCE ]` href="#"         |
| Bio lines               | `&gt;&gt;&gt;` lines in hero  |
| Resume download         | `[ GET RESUME ]` href="#"     |
| OG URL meta tag         | `aryanhanda.dev`              |
